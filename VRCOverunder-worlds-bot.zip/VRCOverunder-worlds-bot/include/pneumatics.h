#include "main.h"

class Pneumatics{
    public:
    pros::ADIDigitalOut climber;
    pros::ADIDigitalOut climber2;
    pros::ADIDigitalOut wings;
    pros::ADIDigitalOut wings2;
    Pneumatics(pros::ADIDigitalOut climber_port, pros::ADIDigitalOut climber_port2, pros::ADIDigitalOut wings, pros::ADIDigitalOut wings2_port);

    void blocker_control();
    void climber_control();
    void wings_control();
    void blocker_initialize();
    void climber_initialize();
    void wings_initialize();
    void wings_v(int value);
    void l_wing(int value);
    void r_wing(int value);
    void climb_v(int value);
};
