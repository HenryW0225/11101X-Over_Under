#include "main.h"

Pneumatics::Pneumatics(pros::ADIDigitalOut climber_port, pros::ADIDigitalOut climber_port2, pros::ADIDigitalOut wings_port, pros::ADIDigitalOut wings2_port) 
    : climber(climber_port),
    climber2(climber_port2),
    wings(wings_port),
    wings2(wings2_port) {}

void Pneumatics::climber_control() {
   if (master.get_digital(DIGITAL_Y)){
        climber_open = !climber_open;
        climber.set_value(climber_open);
        climber2.set_value(climber_open);
        while (master.get_digital(DIGITAL_Y)) {
            pros::delay(util::DELAY_TIME);
        }
    }
}

void Pneumatics::wings_control() {
 if (master.get_digital(DIGITAL_R1)){
        wings_open = !wings_open;
        wings.set_value(wings_open);
        wings2.set_value(wings_open);
        while (master.get_digital(DIGITAL_R1)) {
            pros::delay(util::DELAY_TIME);
        }
    }
}


void Pneumatics::climber_initialize() {
    climber.set_value(0);
}

void Pneumatics::wings_initialize() {
    wings.set_value(0);
    wings2.set_value(0);
}

void Pneumatics::wings_v(int value) {
    wings.set_value(value);
    wings2.set_value(value);
}

void Pneumatics::l_wing(int value)  {
    wings2.set_value(value);
}

void Pneumatics::r_wing(int value)  {
    wings.set_value(value);
}

void Pneumatics::climb_v(int value) {
    climber.set_value(value);
    climber2.set_value(value);
}
