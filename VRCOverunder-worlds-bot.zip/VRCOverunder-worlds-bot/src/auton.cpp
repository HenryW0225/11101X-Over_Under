#include "main.h"

void default_constants(){
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(10, 1, 0, 10, 0);
  chassis.set_heading_constants(6, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);
  // Each exit condition set is in the form (settle_error, settle_time, timeout).
  chassis.set_drive_exit_conditions(1.5, 300, 4000);
  chassis.set_turn_exit_conditions(1, 300, 3000);
  chassis.set_swing_exit_conditions(1, 300, 3000);
}

// Autonomous Procedures
void far_qual(){ 
    //far + bar touch  
    intake.move(120);
    chassis.drive_distance(5, 6, 1, 150, 200, 1, 0, 10, 0);
    pros::delay(160);
    intake.move(0);
    chassis.drive_distance(27, -8, 1, 150, 520, 1, 0, 10, 0);
    chassis.left_swing_to_angle(335, 7, 7, 50, 1000, .3, .001, 2, 15);
    pneumatics.l_wing(1);
    pros::delay(200);
    chassis.drive_distance(12, -5, 1, 150, 540, 1, 0, 10, 0);
    chassis.left_swing_to_angle(270, 5, 7, 50, 1000, .3, .001, 2, 15);
    pros::delay(100);
    pneumatics.l_wing(0);
    chassis.turn_to_angle(297, 7, 10, 50, 500, .4, .03, 3, 15);
    chassis.drive_distance(20, 270, -10, 5, 1, 150, 650, 1, 0, 10, 0, .6, 0, 1, 0);
    //two triballs scored
    chassis.turn_to_angle(270, 7, 10, 50, 500, .4, .03, 3, 15);
    chassis.drive_distance(2, 8, 1, 100, 110, 1, 0, 10, 0);
    chassis.turn_to_angle(100, 7, 10, 50, 1000, .4, .03, 3, 15);
    intake.move(-120);
    pros::delay(330);
    chassis.drive_distance(13, 12, 1, 150, 700, 1, 0, 10, 0);
    //three triballs scored
    chassis.turn_to_angle(90, 8, 10, 50, 500, .4, .03, 3, 15);
    chassis.drive_distance(8, -8, 1, 150, 500, 1, 0, 10, 0);
    intake.move(0);
    chassis.turn_to_angle(20, 7, 10, 50, 500, .4, .03, 3, 15);
    chassis.drive_distance(10, 9, 1, 150, 400, 1, 0, 10, 0);
    intake.move(120);
    chassis.turn_to_angle(45, 8, 10, 50, 500, .4, .03, 3, 15);
    chassis.drive_distance(36, 7, 1, 150, 750, 1, 0, 10, 0);
    chassis.right_swing_to_angle(8, 7, 10, 50, 500, .3, .001, 2, 15);
    chassis.drive_distance(3, 6, 1, 150, 250, 1, 0, 10, 0);
    pneumatics.wings_v(1);
    pros::delay(200);
    intake.move(0);
    chassis.turn_to_angle(10, 7, 10, 50, 800, .4, .03, 3, 15);
    chassis.drive_distance(32, -10, 1, 150, 1000, 1, 0, 10, 0);
    //fourth triball scored
    pneumatics.wings_v(0);
    chassis.drive_distance(5, 8, 1, 150, 250, 1, 0, 10, 0);
    chassis.turn_to_angle(182, 8, 10, 40, 1000, .4, .03, 3, 15);
    intake.move(-120);
    pros::delay(300);
    chassis.drive_distance(8, 10, 1, 150, 525, 1, 0, 10, 0);
    pros::delay(80);
    intake.move(0);
    //fifth triball scored
    chassis.turn_to_angle(180, 7, 10, 40, 1000, .4, .03, 3, 15);
    chassis.drive_distance(13, -8, 1, 150, 610, 1, 0, 10, 0);
    chassis.turn_to_angle(120, 8, 10, 50, 800, .4, .03, 3, 15);
    chassis.drive_distance(31, -10, 1, 150, 730, .8, 0, 10, 0);
    pneumatics.wings_v(1);
    pros::delay(50);
    chassis.turn_to_angle(73, 4, 7, 50, 800, .4, .03, 3, 15);
    chassis.drive_distance(2, -2, 1, 150, 300, 1, 0, 10, 0);
}

void far_elim() {
     //6 ball  
    intake.move(120);
    chassis.drive_distance(5, 6, 1, 150, 200, 1, 0, 10, 0);
    pros::delay(190);
    intake.move(0);
    chassis.drive_distance(27, -8, 1, 150, 520, 1, 0, 10, 0);
    chassis.left_swing_to_angle(335, 7, 7, 50, 1000, .3, .001, 2, 15);
    pneumatics.l_wing(1);
    pros::delay(150);
    chassis.drive_distance(12, -5, 1, 150, 540, 1, 0, 10, 0);
    chassis.left_swing_to_angle(270, 5, 7, 50, 1000, .3, .001, 2, 15);\
    pneumatics.l_wing(0);
    pros::delay(50);
    chassis.turn_to_angle(297, 7, 10, 50, 500, .4, .03, 3, 15);
    chassis.drive_distance(20, 270, -10, 5, 1, 150, 650, 1, 0, 10, 0, .6, 0, 1, 0);
    //two triballs scored
    chassis.turn_to_angle(270, 8, 10, 50, 500, .4, .03, 3, 15);
    chassis.drive_distance(2, 8, 1, 100, 110, 1, 0, 10, 0);
    chassis.turn_to_angle(100, 8, 10, 50, 1000, .4, .03, 3, 15);
    intake.move(-120);
    pros::delay(330);
    chassis.drive_distance(12, 12, 1, 150, 650, 1, 0, 10, 0);
    //three triballs scored
    chassis.turn_to_angle(90, 8, 10, 50, 500, .4, .03, 3, 15);
    chassis.drive_distance(8, -8, 1, 150, 500, 1, 0, 10, 0);
    intake.move(0);
    chassis.turn_to_angle(26, 8, 10, 50, 500, .4, .03, 3, 15);
    intake.move(120);
    chassis.drive_distance(29, 9, 1, 150, 830, 1, 0, 10, 0);
    chassis.left_swing_to_angle(0, 5, 7, 50, 800, .3, .001, 2, 15);
    intake.move(0);
    chassis.drive_distance(4, -6, 1, 150, 200, 1, 0, 10, 0);
    chassis.turn_to_angle(138, 7, 10, 50, 1000, .4, .03, 3, 15);
    intake.move(-120);
    chassis.drive_distance(7, 8, 1, 150, 330, 1, 0, 10, 0);
    pros::delay(200);
    chassis.drive_distance(3, -6, 1, 150, 240, 1, 0, 10, 0);
    //fourth triball outaked near goal
    chassis.turn_to_angle(57, 7, 10, 50, 500, .4, .03, 3, 15);
    intake.move(120);
    chassis.drive_distance(13, 8, 1, 150, 460, 1, 0, 10, 0);
    chassis.right_swing_to_angle(8, 7, 10, 50, 500, .3, .001, 2, 15);
    chassis.drive_distance(2, 8, 1, 150, 200, 1, 0, 10, 0);
    pneumatics.wings_v(1);
    pros::delay(140);
    intake.move(0);
    chassis.turn_to_angle(9, 8, 10, 50, 800, .4, .03, 3, 15);
    chassis.drive_distance(32, -10, 1, 150, 1050, 1, 0, 10, 0);
   //fourth + fifth triball scored
    pneumatics.wings_v(0);
    chassis.drive_distance(4, 8, 1, 150, 270, 1, 0, 10, 0);
    chassis.turn_to_angle(180, 7, 10, 50, 1000, .4, .03, 3, 15);
    intake.move(-120);
    pros::delay(300);
    chassis.drive_distance(8, 10, 1, 150, 525, 1, 0, 10, 0);
    pros::delay(50);
    intake.move(0);
    //sixth triball scored
    chassis.turn_to_angle(175, 7, 10, 40, 1000, .4, .03, 3, 15);
    chassis.drive_distance(5, -6, 1, 150, 300, .5, 0, 5, 0);
    chassis.turn_to_angle(110, 8, 10, 40, 1000, .4, .03, 3, 15);
}

void close_qual() {
  //no disrupt AwP, wings back, ziptie touch
  chassis.set_heading(315);
  chassis.drive_distance(9, 8, 1, 150, 400, 1, 0, 10, 0);
  pneumatics.l_wing(1);
  pros::delay(250);
  chassis.drive_distance(10, -4, 1, 150, 600, 1, 0, 10, 0);
  pros::delay(50);
  chassis.turn_to_angle(210, 5, 10, 50, 1000, .4, .03, 3, 15);  
  pneumatics.wings_v(0);
  chassis.drive_distance(10, -4, 1, 150, 500, 1, 0, 10, 0);
  chassis.turn_to_angle(180, 6, 10, 50, 1000, .4, .03, 3, 15);
  chassis.drive_distance(7.5, 8, 1, 150, 420, 1, 0, 10, 0);
  chassis.turn_to_angle(91, 6, 10, 50, 1000, .4, .03, 3, 15);
  intake.move(-120);
  chassis.drive_distance(35, 6, 1, 150, 700, .8, 0, 10, 0);
  chassis.turn_to_angle(90, 5, 10, 50, 1000, .4, .03, 3, 15);
  pros::delay(2000);
  intake.move(0);
}

void close_elim(){
  //world close elim steal+preload
  chassis.set_heading(0);
  pneumatics.l_wing(1);
  intake.move(120);
  pros::delay(100);
  pneumatics.l_wing(0);
  pros::delay(50);
  chassis.drive_distance(52, 20, 8, 5, 1, 100, 1600, 1, 0, 10, 0, .4, 0, 1, 0);
  pros::delay(120);
  intake.move(0);
  //first triball intaked
  chassis.left_swing_to_angle(270, 7, 3, 50, 1000, .3, .001, 2, 15);
  pneumatics.l_wing(1);
  pros::delay(50);
  chassis.left_swing_to_angle(180, 7, 3, 50, 1000, .3, .001, 2, 15);
  chassis.drive_distance(3, 163, -4, 4, 1, 100, 250, .7, 0, 10, 0, .7, 0, 1, 0);
  pneumatics.l_wing(0);
  //second triball knocked
  chassis.drive_distance(4, 9, 1, 100, 400, 1, 0, 10, 0);
  chassis.turn_to_angle(225, 7, 3, 50, 1000, .4, .03, 3, 15);
  chassis.drive_distance(37, 9, 1, 100, 1000, 1, 0, 10, 0);
  chassis.turn_to_angle(180, 9, 10, 50, 1000, .4, .03, 3, 15);
  chassis.drive_distance(20, 9, 1, 100, 810, 1, 0, 10, 0);
  chassis.turn_to_angle(112, 7, 3, 50, 1000, .3, .001, 2, 15);
  chassis.drive_distance(13, -9, 1, 100, 470, 1, 0, 10, 0);
  chassis.right_swing_to_angle(183, 7, 3, 50, 1000, .3, .001, 2, 15);
  chassis.drive_distance(18, -10, 1, 100, 900, 1, 0, 10, 0);
  //preload scored
  chassis.turn_to_angle(180, 7, 10, 50, 1000, .4, .03, 3, 15);
  chassis.drive_distance(5, 9, 1, 100, 400, 1, 0, 10, 0);
  chassis.turn_to_angle(140, 7, 10, 50, 1000, .4, .03, 3, 15);
  chassis.drive_distance(36, 9, 1, 100, 1000, 1, 0, 10, 0);
  chassis.turn_to_angle(90, 7, 10, 50, 1000, .4, .03, 3, 15);
  intake.move(-120);
  chassis.drive_distance(28, 9, 1, 100, 1000, 1, 0, 10, 0);
  pros::delay(200);
  //triballs outaked
  chassis.turn_to_angle(90, 5, 7, 50, 1000, .4, .03, 3, 15);
  chassis.drive_distance(-33, 9, 1, 100, 1170, 1, 0, 10, 0);
  intake.move(0);
  chassis.turn_to_angle(110, 7, 7, 50, 1000, .4, .03, 3, 15);
  chassis.drive_distance(-22, 9, 1, 100, 950, 1, 0, 10, 0);
  chassis.turn_to_angle(133, 7, 7, 50, 1000, .4, .03, 3, 15);
  pneumatics.r_wing(1);
  pros::lcd::set_text(2, "slayy girl boss!");
}

void SWP(){
    chassis.set_heading(315);
    chassis.drive_distance(9, 8, 1, 150, 400, 1, 0, 10, 0);
    pneumatics.l_wing(1);
    pros::delay(250);
    chassis.drive_distance(10, -4, 1, 150, 600, 1, 0, 10, 0);
    pros::delay(50);
    chassis.turn_to_angle(220, 5, 7, 50, 1000, .4, .03, 3, 15);  
    pneumatics.wings_v(0);
    chassis.drive_distance(28, -7, 1, 150, 1000, 1, 0, 10, 0);
    chassis.turn_to_angle(90, 6, 10, 50, 1000, .4, .03, 3, 15);
    intake.move(-120);
    chassis.drive_distance(2, 4, 1, 150, 300, .6, 0, 10, 0);
    pros::delay(400);
    chassis.drive_distance(8, -8, 1, 150, 500, 1, 0, 10, 0);
    intake.move(0);
    chassis.turn_to_angle(271, 5, 7, 50, 1000, .4, .03, 3, 15);
    pneumatics.wings_v(1);
    pros::delay(200);
    chassis.drive_distance(15, -11, 1, 150, 1000, 1, 0, 10, 0);
    chassis.turn_to_angle(350, 5, 7, 50, 1000, .4, .03, 3, 15);
    pneumatics.wings_v(1);
    pros::delay(200);
    chassis.drive_distance(22, -6, 1, 150, 1000, 1, 0, 10, 0);
    chassis.turn_to_angle(20, 5, 10, 50, 1000, .4, .03, 3, 15);
}

void skills(){
    //Auton skills
    chassis.set_heading(180);
    chassis.turn_to_angle(130, 9, 7, 50, 1000, .4, .03, 3, 15); 
    chassis.drive_distance(26, 180, -10, 5, 2, 50, 1200, 1, 0, 10, 0, .3, 0, 1, 0);
    chassis.turn_to_angle(180, 9, 7, 50, 1000, .4, .03, 3, 15); 
    chassis.drive_distance(3, -10, 1, 150, 300, 1, 0, 10, 0); 
    chassis.drive_distance(7, 10, 1, 150, 300, 1, 0, 10, 0); 
    chassis.turn_to_angle(72, 9, 7, 50, 1000, .4, .03, 3, 15); 
    chassis.drive_distance(2, -5, 1, 150, 170, 1, 0, 10, 0);
    pneumatics.r_wing(1);
    //slapper.move(120);
    pros::delay(500);
    slapper.move(0);
    chassis.set_heading(72);
    pneumatics.wings_v(0);
    pros::delay(50);
    //done match-loading
    chassis.drive_distance(22, 85, 10, 4, 2, 50, 720, 1, 0, 10, 0, .27, 0, 1, 0);
    chassis.turn_to_angle(200, 9, 7, 50, 1000, .4, .03, 3, 15); 
    pneumatics.wings_v(1);
    pros::delay(100);
    chassis.drive_distance(40, -12, 1, 150, 1200, 1, 0, 10, 0); 
    chassis.turn_to_angle(185, 9, 7, 50, 1000, .4, .03, 3, 15); 
    chassis.drive_distance(7, 10, 1, 150, 350, 1, 0, 10, 0); 
    chassis.turn_to_angle(200, 9, 7, 50, 1000, .4, .03, 3, 15); 
    chassis.drive_distance(11, -12, 1, 150, 900, 1, 0, 10, 0); 
    pneumatics.wings_v(0);
    //sweep done
    chassis.drive_distance(2, 10, 1, 100, 130, 1, 0, 10, 0); 
    chassis.turn_to_angle(110, 9, 7, 50, 1000, .4, .03, 3, 15); 
    chassis.drive_distance(23, -10, 1, 150, 740, 1, 0, 10, 0);
    //chassis.right_swing_to_angle(225, 9, 8, 50, 800, .3, .001, 2, 15);
    chassis.right_swing_to_angle(225, 9, 8, 50, 800, .3, .001, 2, 15);
    chassis.drive_distance(4, -10, 1, 150, 300, 1, 0, 10, 0);
    chassis.right_swing_to_angle(271, 9, 10, 50, 500, .3, .001, 2, 15);
    pneumatics.l_wing(1);
    pros::delay(50);
    chassis.turn_to_angle(272, 9, 7, 50, 1000, .4, .03, 3, 15); 
    chassis.drive_distance(-80, 277, 10, 2, 1.5, 50, 1250, 1, 0, 10, 0, .38, 0, 1, 0);
    //chassis.right_swing_to_angle(305, 9, 7, 50, 500, .3, .001, 2, 15);
    chassis.right_swing_to_angle(305, 9, 7, 50, 500, .3, .001, 2, 15);
    chassis.drive_distance(14, -10, 1, 150, 560, 1, 0, 10, 0);
    chassis.right_swing_to_angle(5, 9, 7, 50, 500, .3, .001, 2, 15);
    chassis.drive_distance(16, -12, 1, 150, 900, 1, 0, 10, 0);
    pneumatics.wings_v(0);
    chassis.turn_to_angle(0, 9, 3, 50, 1000, .4, .03, 3, 15);
    chassis.drive_distance(2, 10, 1, 50, 170, 1.5, 0, 10, 0);
    chassis.turn_to_angle(0, 9, 3, 50, 900, .4, .03, 3, 15);
    pros::delay(50);
    chassis.drive_distance(14, -12, 1, 10, 850, 1.5, 0, 10, 0);
    //push 1 complete
    chassis.turn_to_angle(0, 9, 3, 50, 1000, .4, .03, 3, 15);
    chassis.drive_distance(1, 10, 1, 50, 100, 1.5, 0, 10, 0);
    chassis.turn_to_angle(84, 9, 3, 50, 1000, .4, .03, 3, 15);
    pneumatics.l_wing(1);
    pros::delay(100);
    chassis.drive_distance(33, -10, 2, 40, 570, 1.5, 0, 10, 0);
    chassis.left_swing_to_angle(295, 9, 3, 50, 1000, .4, .03, 3, 15);
    chassis.drive_distance(29, 270, -11, 3, 2, 50, 800, 1, 0, 10, 0, .37, 0, 1, 0);
    pneumatics.wings_v(0);
    pros::delay(50);
    //push 2 complete
    chassis.turn_to_angle(275, 9, 3, 50, 1000, .4, .03, 3, 15);
    chassis.drive_distance(10, 10, 1.5, 50, 280, 1.5, 0, 10, 0);
    chassis.turn_to_angle(10, 9, 3, 50, 1000, .4, .03, 3, 15);
    pneumatics.l_wing(1);
    pros::delay(100);
    chassis.drive_distance(3, -10, 1.5, 50, 100, 1.5, 0, 10, 0);
    chassis.left_swing_to_angle(270, 9, 5, 10, 1000, .4, .03, 3, 15);
    pneumatics.r_wing(1);
    pros::delay(100);
    chassis.drive_distance(23, 270, -10, 3, 1.5, 50, 900, 1.5, 0, 10, 0, .2, 0, 1, 0);
    //chassis.drive_distance(21, -10, 1.5, 50, 800, 1.5, 0, 10, 0);
    /*chassis.drive_distance(5, 10, 1.5, 50, 440, 1.5, 0, 10, 0);
    pros:delay(150);
    //chassis.turn_to_angle(270, 9, 5, 10, 1000, .4, .03, 3, 15);
    chassis.drive_distance(27, -10, 1.5, 50, 900, 1.5, 0, 10, 0);
    */pneumatics.wings_v(0);
    chassis.turn_to_angle(275, 9, 5, 10, 1000, .4, .03, 3, 15);
    chassis.drive_distance(9, 10, 1.5, 50, 330, 1.5, 0, 10, 0);
    //push #3 complete
    chassis.left_swing_to_angle(5, 9, 3, 50, 1000, .4, .03, 3, 15);
    chassis.drive_distance(8, -10, 1.5, 50, 450, 1.5, 0, 10, 0);
    pneumatics.l_wing(1);
    pros::delay(100);
    chassis.left_swing_to_angle(242, 9, 3, 50, 1500, .4, .03, 3, 15);
    pneumatics.r_wing(1);
    pros::delay(100);
    chassis.drive_distance(20, 262, -10, 2, 2, 50, 800, 1, 0, 10, 0, .3, 0, 1, 0);
    chassis.drive_distance(5, 10, 1.5, 50, 400, 1.5, 0, 10, 0);
    chassis.drive_distance(20, -10, 1.5, 50, 740, 1.5, 0, 10, 0);
    //push #4 complete
    pneumatics.wings_v(0);
    chassis.turn_to_angle(270, 9, 5, 10, 1000, .4, .03, 3, 15);
    chassis.drive_distance(1, 10, 1.5, 50, 100, 1.5, 0, 10, 0);
    chassis.turn_to_angle(346, 9, 3, 50, 1000, .4, .03, 3, 15);
    pneumatics.l_wing(1);
    pros::delay(100);
    chassis.drive_distance(27, -10, 1.5, 10, 900, 1.5, 0, 10, 0);
    chassis.left_swing_to_angle(235, 9, 3, 10, 1000, .4, .03, 3, 15);
    pneumatics.wings_v(0);
    pros::delay(150);
    chassis.drive_distance(9, -10, 1.5, 20, 500, 1.5, 0, 10, 0);
    chassis.turn_to_angle(193, 9, 3, 50, 1000, .4, .03, 3, 15);
    chassis.drive_distance(15, -10, 1, 100, 1000, 1.5, 0, 10, 0);
    chassis.drive_distance(1, 10, 1, 10, 200, 1.5, 0, 10, 0);
    chassis.turn_to_angle(190, 9, 3, 50, 1000, .4, .03, 3, 15);
    chassis.drive_distance(15, -10, 1, 100, 1000, 1.5, 0, 10, 0);
    //fifth push done going to climb
    chassis.drive_distance(5, 10, 1, 10, 300, 1.5, 0, 10, 0);
    chassis.turn_to_angle(225, 9, 3, 50, 1000, .4, .03, 3, 15);
    chassis.drive_distance(10, 10, 1, 10, 500, 1.5, 0, 10, 0);
    chassis.turn_to_angle(270, 9, 3, 50, 1000, .4, .03, 3, 15);
    pneumatics.climb_v(1);
    pros::delay(100);
    chassis.drive_distance(24, 10, 1, 10, 650, 1.5, 0, 10, 0);
    pneumatics.climb_v(0);
}

void test(){
  /*slapper.move(120);
  pros::delay(2500);
  int count = 0;
  while (true){
    if (chassis.get_rotation() > 23000 and chassis.get_rotation() < 32000){
      slapper.move(0);
      break;
    }
    if (count > 1500){
      break;
    }
    pros::delay(5); 
    count += 5;
  }*/
  //curving while driving
  //chassis.drive_distance(24, 50, 8, 2, 2, 50, 2000, 1.5, 1, 10, 0, .3, 0, 1, 0);
}
